# @daintreehq/plugin-vite

Vite externals preset for Daintree plugins.

Daintree's renderer ships one React 19 instance in a shared `vendor-react` chunk and injects a `<script type="importmap">` that maps each served specifier — `react`, `react/jsx-runtime`, `react/jsx-dev-runtime`, `react-dom`, `react-dom/client` — to its own small facade module re-exporting that specifier's public API from the shared chunk. The map deliberately does not point at the chunk itself: a code-split chunk only exports the private interface other chunks import from it, so a bare `import { useState } from "react"` would fail to load. Plugin bundles need to externalize those specifiers so they resolve, at runtime, to the host's single React instance — bundling a second copy produces "Invalid hook call" the first time JSX renders. The map also serves `@daintreehq/tour`, `@daintreehq/tour/react`, `@daintreehq/tour/kit` and `@daintreehq/tour/mock-app` from the host's single tour instance, which the preset leaves external too: a tour scene that bundled its own copy would bind to its own player context and never see the host's cues. It serves `@daintreehq/plugin-ui` as well, the host's own UI kit ([reference](../../docs/plugins/ui-kit.md)), which has no package to bundle at all and so stays external. The preset fails the build on any React, tour or plugin-ui subpath the map does not serve (`react-dom/server`, say), so an externalized-but-unmapped import is caught at build time rather than as an unresolved specifier at load.

## Usage

```ts
// vite.config.ts in a plugin
import { defineConfig } from "vite";
import { daintreePlugin } from "@daintreehq/plugin-vite";

export default defineConfig({
  plugins: [daintreePlugin()],
  build: {
    lib: { entry: "src/index.tsx", formats: ["es"] },
  },
});
```

The plugin sets `build.rollupOptions.external` to a function that externalizes every `react`, `react-dom`, `@daintreehq/tour` and `@daintreehq/plugin-ui` specifier the host import map serves, and fails the build on any other subpath of those packages. It matches whole package prefixes rather than exact names on purpose — `external: ["react"]` only matches the literal `"react"` and silently bundles `react/jsx-runtime` into plugin output. Externals you pass in `externals`, or already set in `build.rollupOptions.external`, are folded in.

The import map also serves `@daintreehq/plugin-sdk/react` to zero-build views, which have no bundler to supply it. The preset deliberately does **not** externalize that specifier: a bundled view keeps bundling the SDK version it pinned, so a Daintree upgrade never swaps its hooks out from under it. `HOST_IMPORTMAP_SPECIFIERS` (the externals contract) and `HOST_IMPORTMAP_RAW_ONLY_SPECIFIERS` in `src/hostImportMap.ts` keep the two lists apart.

## Document packages

Use `documentPackages` for libraries that register document globals, such as Lexxy and Trix. Each entry builds independently into one content-addressed JavaScript asset; the virtual import exports an asynchronous loader. Matching document-scoped packages execute once across plugins and hot reloads. Different versions or bundle hashes are refused until the project window reloads.

```ts
daintreePlugin({
  documentPackages: {
    "@acme/markdown-editor": {
      entry: "src/editor-adapter.ts",
      version: "1.0.0",
      scope: "document",
    },
  },
});
```

```ts
import loadEditor from "virtual:daintree-document-package/@acme/markdown-editor";
const editor = await loadEditor();
```

The default scope is `"plugin"`; use `"document"` explicitly when cooperating trusted plugins must share global registration. This is a module-lifetime boundary, not a security sandbox. Keep the complete editor integration in the adapter, styles in the view build, and per-panel state in per-instance objects. See [the full contract and security recommendations](../../docs/plugins/document-packages.md).
