// Types for the `window.electron.plugin` bridge a plugin view talks to its
// worker through. The bridge is injected by the running app, so there is no
// module to import: this ambient declaration is how TypeScript learns it
// exists. Opt in with
// `"types": ["@daintreehq/plugin-sdk/view-globals"]` in tsconfig, or
// `/// <reference types="@daintreehq/plugin-sdk/view-globals" />` in one file.
//
// Only the documented plugin-view surface is declared: `invoke`, `on`,
// `onPanel` and the project-presence pair. Everything else the host puts on
// `window.electron` is the app's own and can change without notice, so it is
// deliberately absent here — a view that reaches for it should get a type
// error.
//
// Self-contained on purpose: importing the bridge type from `/react` would
// pull React's declarations into a view that does not use React. The SDK's
// `PluginHostBridge` (from `/react`) has the same shape, and a type test holds
// the two to it in both directions.

declare global {
  /** The plugin-view bridge on `window.electron.plugin`. */
  interface DaintreePluginViewBridge {
    /** Call a `host.registerHandler(channel, …)` handler; resolves its result. */
    invoke(pluginId: string, channel: string, ...args: unknown[]): Promise<unknown>;
    /** Receive `host.postToPanel(channel, payload)` broadcasts. Returns the unsubscribe. */
    on(pluginId: string, channel: string, callback: (payload: unknown) => void): () => void;
    /** Receive pushes targeted at one panel instance. Returns the unsubscribe. */
    onPanel(
      pluginId: string,
      channel: string,
      panelId: string,
      callback: (payload: unknown) => void
    ): () => void;
    /**
     * This view's own project presence, or `null` in a view with no project.
     * Absent on a Daintree that predates it.
     */
    getProjectPresence?(): Promise<DaintreePluginProjectPresence | null>;
    /** Receive presence changes pushed to this view's project. Returns the unsubscribe. */
    onProjectPresenceChanged?(
      callback: (presence: DaintreePluginProjectPresence) => void
    ): () => void;
  }

  /** A project's presence: shown in some window, open behind another, or closed. */
  interface DaintreePluginProjectPresence {
    readonly projectId: string;
    readonly state: "foreground" | "background" | "closed";
  }

  /** What a plugin view may use on `window.electron`. */
  interface DaintreePluginViewElectron {
    readonly plugin: DaintreePluginViewBridge;
  }

  interface Window {
    readonly electron: DaintreePluginViewElectron;
  }
}

export {};
